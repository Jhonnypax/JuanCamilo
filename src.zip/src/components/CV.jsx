import React from 'react'
import "../styles/CV.css"

const CV = () => {
  return (
    <div>contact</div>
  )
}

export default CV