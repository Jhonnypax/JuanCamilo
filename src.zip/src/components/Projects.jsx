import React from 'react'
import "../styles/Projects.css"

const Button = ({ text }) => {
  return <button className="custom-button">{text}</button>;
};

const projects = () => {
  return (
    <div className="Projects">
    <h2>FRONT AND BACK END</h2>
    <br />
    <div className="button-row">
      <Button text="Button 1" />
      <Button text="Button 2" />
    </div>
    <div className="button-row">
      <Button text="Button 3" />
      <Button text="Button 4" />
    </div>
    <br />
    <br />
    <h2>UX</h2>
    <br />
    <div className="button-row">
      <Button text="Button 5" />
      <Button text="Button 6" />
    </div>
    <div className="button-row">
      <Button text="Button 7" />
      <Button text="Button 8" />
    </div>
  </div>
  )
}

export default projects