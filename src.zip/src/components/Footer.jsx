import React from 'react'
import '../styles/Footer.css'

export const Footer = () => {
  return (
    <div className='foot'>
     <p> © Juan Camilo Paez, Bogota, Colombia</p>
    </div>
  )
}

export default Footer